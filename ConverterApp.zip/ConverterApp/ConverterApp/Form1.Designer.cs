﻿namespace ConverterApp
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInputValue = new System.Windows.Forms.Label();
            this.txtInputValue = new System.Windows.Forms.TextBox();
            this.btnConvertBtn = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lblConvertType1 = new System.Windows.Forms.Label();
            this.lblConvertType2 = new System.Windows.Forms.Label();
            this.txtConvertOut = new System.Windows.Forms.TextBox();
            this.cbxSelection = new System.Windows.Forms.ComboBox();
            this.convertLbl = new System.Windows.Forms.Label();
            this.listBoxHistory = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInputValue
            // 
            this.lblInputValue.AutoSize = true;
            this.lblInputValue.Location = new System.Drawing.Point(7, 24);
            this.lblInputValue.Name = "lblInputValue";
            this.lblInputValue.Size = new System.Drawing.Size(127, 17);
            this.lblInputValue.TabIndex = 0;
            this.lblInputValue.Text = "Number to Convert";
            // 
            // txtInputValue
            // 
            this.txtInputValue.Location = new System.Drawing.Point(142, 21);
            this.txtInputValue.Name = "txtInputValue";
            this.txtInputValue.Size = new System.Drawing.Size(100, 22);
            this.txtInputValue.TabIndex = 1;
            // 
            // btnConvertBtn
            // 
            this.btnConvertBtn.Location = new System.Drawing.Point(142, 88);
            this.btnConvertBtn.Name = "btnConvertBtn";
            this.btnConvertBtn.Size = new System.Drawing.Size(100, 23);
            this.btnConvertBtn.TabIndex = 3;
            this.btnConvertBtn.Text = "Convert!";
            this.btnConvertBtn.UseVisualStyleBackColor = true;
            this.btnConvertBtn.Click += new System.EventHandler(this.convertBtn_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(274, 220);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 23);
            this.btn_Exit.TabIndex = 4;
            this.btn_Exit.Text = "EXIT";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // lblConvertType1
            // 
            this.lblConvertType1.AutoSize = true;
            this.lblConvertType1.Location = new System.Drawing.Point(9, 159);
            this.lblConvertType1.Name = "lblConvertType1";
            this.lblConvertType1.Size = new System.Drawing.Size(0, 17);
            this.lblConvertType1.TabIndex = 5;
            // 
            // lblConvertType2
            // 
            this.lblConvertType2.AutoSize = true;
            this.lblConvertType2.Location = new System.Drawing.Point(93, 223);
            this.lblConvertType2.Name = "lblConvertType2";
            this.lblConvertType2.Size = new System.Drawing.Size(0, 17);
            this.lblConvertType2.TabIndex = 6;
            // 
            // txtConvertOut
            // 
            this.txtConvertOut.Location = new System.Drawing.Point(12, 220);
            this.txtConvertOut.Name = "txtConvertOut";
            this.txtConvertOut.Size = new System.Drawing.Size(71, 22);
            this.txtConvertOut.TabIndex = 7;
            // 
            // cbxSelection
            // 
            this.cbxSelection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSelection.FormattingEnabled = true;
            this.cbxSelection.Location = new System.Drawing.Point(142, 58);
            this.cbxSelection.Name = "cbxSelection";
            this.cbxSelection.Size = new System.Drawing.Size(121, 24);
            this.cbxSelection.TabIndex = 2;
            // 
            // convertLbl
            // 
            this.convertLbl.AutoSize = true;
            this.convertLbl.Location = new System.Drawing.Point(12, 61);
            this.convertLbl.Name = "convertLbl";
            this.convertLbl.Size = new System.Drawing.Size(122, 17);
            this.convertLbl.TabIndex = 9;
            this.convertLbl.Text = "Select Conversion";
            // 
            // listBoxHistory
            // 
            this.listBoxHistory.FormattingEnabled = true;
            this.listBoxHistory.ItemHeight = 16;
            this.listBoxHistory.Location = new System.Drawing.Point(12, 280);
            this.listBoxHistory.Name = "listBoxHistory";
            this.listBoxHistory.Size = new System.Drawing.Size(340, 116);
            this.listBoxHistory.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(142, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "History:";
            // 
            // frm_Main
            // 
            this.AcceptButton = this.btnConvertBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 409);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxHistory);
            this.Controls.Add(this.convertLbl);
            this.Controls.Add(this.cbxSelection);
            this.Controls.Add(this.txtConvertOut);
            this.Controls.Add(this.lblConvertType2);
            this.Controls.Add(this.lblConvertType1);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btnConvertBtn);
            this.Controls.Add(this.txtInputValue);
            this.Controls.Add(this.lblInputValue);
            this.Name = "frm_Main";
            this.Text = "ATCA Gas Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInputValue;
        private System.Windows.Forms.TextBox txtInputValue;
        private System.Windows.Forms.Button btnConvertBtn;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lblConvertType1;
        private System.Windows.Forms.Label lblConvertType2;
        private System.Windows.Forms.TextBox txtConvertOut;
        private System.Windows.Forms.ComboBox cbxSelection;
        private System.Windows.Forms.Label convertLbl;
        private System.Windows.Forms.ListBox listBoxHistory;
        private System.Windows.Forms.Label label1;
    }
}

