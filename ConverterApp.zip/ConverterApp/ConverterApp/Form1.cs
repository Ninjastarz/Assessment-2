﻿using System;
using System.Windows.Forms;

namespace ConverterApp
// This program was written by Gail Mosdell
// It forms the base of a converter program for the OS-Assessment Two for Cert IV
// Date : February 2017
{
    public partial class frm_Main : Form
    {
        public int counter = 0;
        double[] history = new double[10];
        public string[] conversionType = { "", "Cm To Inch", "Metres to Feet", "Celsius To Fahrenheit", "Cm To Feet", "Km To Miles" };
        public frm_Main()
        {
            InitializeComponent();
            cbxSelection.DataSource = conversionType;
        }

        // Global Variables and Constants
        double validInputDbl, convertedOutput;

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void convertBtn_Click(object sender, EventArgs e)
        {
            bool validInput = double.TryParse(txtInputValue.Text, out validInputDbl);
            if (!validInput)
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txtInputValue.Clear();
                txtInputValue.Focus();
                txtConvertOut.Clear();
                lblConvertType2.Text = "";
                lblConvertType1.Text = "";
            }
            else
            {
                switch (cbxSelection.SelectedIndex)
                {
                    case 0:
                        MessageBox.Show("Please Choose a Conversion type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    case 1:
                        //Cm to Inch conversion
                        convertedOutput = validInputDbl * 0.3937;
                        txtConvertOut.Text = convertedOutput.ToString();
                        lblConvertType1.Text = txtInputValue.Text + " Centimetres is converted to:";
                        lblConvertType2.Text = " Inches.";
                        txtInputValue.Clear();
                        break;

                    case 2:
                        //Metres to Feet conversion
                        convertedOutput = validInputDbl * 3.28084;
                        txtConvertOut.Text = convertedOutput.ToString();
                        lblConvertType1.Text = txtInputValue.Text + " Metres is converted to:";
                        lblConvertType2.Text = " Feet.";
                        txtInputValue.Clear();
                        break;

                    case 3:
                        //Celsius to Fahrenheit conversion
                        convertedOutput = (validInputDbl * 9) / 5 + 32;
                        txtConvertOut.Text = convertedOutput.ToString();
                        lblConvertType1.Text = txtInputValue.Text + "°C is converted to:";
                        lblConvertType2.Text = "°F.";
                        txtInputValue.Clear();
                        break;

                    case 4:
                        //Cm to Feet conversion
                        convertedOutput = validInputDbl * 0.0328084;
                        txtConvertOut.Text = convertedOutput.ToString();
                        lblConvertType1.Text = txtInputValue.Text + " Centimetres is converted to:";
                        lblConvertType2.Text = " Feet.";
                        txtInputValue.Clear();
                        break;

                    case 5:
                        //Km to Miles conversion
                        convertedOutput = validInputDbl * 0.621371;
                        txtConvertOut.Text = convertedOutput.ToString();
                        lblConvertType1.Text = txtInputValue.Text + " Kilometres is converted to:";
                        lblConvertType2.Text = " Miles.";
                        txtInputValue.Clear();
                        break;

                    default:
                        MessageBox.Show("Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            //adds the result to an array then draws from the array to put in a listbox.
            if (cbxSelection.SelectedIndex != 0 & validInput)
            {
                history[counter] = convertedOutput;
                listBoxHistory.Items.Add
                    (String.Format("{0} {3} = {1} {2}", validInputDbl, history[counter], lblConvertType2.Text, cbxSelection.SelectedValue));
                txtInputValue.Focus();
                //increments a counter within the bounds of 1 - 10.
                if (counter < 9)
                {
                    counter++;
                }
                else
                {
                    counter = 0;
                }
            }          
        }
    }
}
